{
	"sorting": null,
	"family": "multiple_choice",
	"subtype": "vertical",
	"required": null,
	"answers": {
		"other": {
			"num_lines": 1,
			"text": "Date (DD\/MM\/YYYY)",
			"id": "1138208091",
			"visible": true,
			"apply_all_rows": false,
			"is_answer_choice": true,
			"position": 0,
			"num_chars": 50,
			"error_text": "label is required"
		},
		"choices": [{
				"visible": true,
				"text": "Reliable",
				"position": 1,
				"id": "1138208074"
			}, {
				"visible": true,
				"text": "High quality ",
				"position": 2,
				"id": "1138208075"
			}, {
				"visible": true,
				"text": "Useful",
				"position": 3,
				"id": "1138208076"
			}, {
				"visible": true,
				"text": "Unique",
				"position": 4,
				"id": "1138208077"
			}, {
				"visible": true,
				"text": "Good value for money",
				"position": 5,
				"id": "1138208078"
			}, {
				"visible": true,
				"text": "Overpriced",
				"position": 6,
				"id": "1138208079"
			}, {
				"visible": true,
				"text": "Impractical",
				"position": 7,
				"id": "1138208080"
			}, {
				"visible": true,
				"text": "Ineffective",
				"position": 8,
				"id": "1138208081"
			}, {
				"visible": true,
				"text": "Poor quality",
				"position": 9,
				"id": "1138208082"
			}, {
				"visible": true,
				"text": "Unreliable",
				"position": 10,
				"id": "1138208083"
			}
		]
	},
	"visible": true,
	"href": "https:\/\/api.surveymonkey.net\/v3\/surveys\/121392425\/pages\/47361250\/questions\/157148990",
	"headings": [{
			"heading": "Which of the following words would you use to describe our products? Select all that apply."
		}
	],
	"position": 1,
	"validation": {
		"sum_text": "",
		"min": "2017-08-19",
		"text": "should be a date",
		"sum": null,
		"max": "2017-09-01",
		"type": "date_intl"
	},
	"id": "157148990",
	"forced_ranking": false
}
