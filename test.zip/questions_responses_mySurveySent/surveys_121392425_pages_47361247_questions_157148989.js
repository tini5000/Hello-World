{
	"sorting": null,
	"family": "single_choice",
	"subtype": "vertical",
	"required": null,
	"answers": {
		"choices": [{
				"visible": true,
				"text": "Africa",
				"position": 1,
				"id": "1138208067"
			}, {
				"visible": true,
				"text": "Antarctica",
				"position": 2,
				"id": "1138208068"
			}, {
				"visible": true,
				"text": "Asia",
				"position": 3,
				"id": "1138208069"
			}, {
				"visible": true,
				"text": "Australia",
				"position": 4,
				"id": "1138208070"
			}, {
				"visible": true,
				"text": "Europe",
				"position": 5,
				"id": "1138208071"
			}, {
				"visible": true,
				"text": "North America",
				"position": 6,
				"id": "1138208072"
			}, {
				"visible": true,
				"text": "South America",
				"position": 7,
				"id": "1138208073"
			}
		]
	},
	"visible": true,
	"href": "https:\/\/api.surveymonkey.net\/v3\/surveys\/121392425\/pages\/47361247\/questions\/157148989",
	"headings": [{
			"heading": "On which continent were you born?"
		}
	],
	"position": 1,
	"validation": null,
	"id": "157148989",
	"forced_ranking": false
}
