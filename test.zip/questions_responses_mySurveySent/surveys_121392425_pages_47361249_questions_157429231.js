{
	"display_options": {
		"middle_label": "",
		"show_display_number": true,
		"display_subtype": "",
		"right_label": "100",
		"display_type": "slider",
		"custom_options": {
			"starting_position": 0,
			"option_set": [],
			"step_size": 1
		},
		"left_label": "0"
	},
	"sorting": null,
	"family": "open_ended",
	"subtype": "single",
	"required": null,
	"visible": true,
	"href": "https:\/\/api.surveymonkey.net\/v3\/surveys\/121392425\/pages\/47361249\/questions\/157429231",
	"headings": [{
			"heading": "On a scale of 1 to 100, how much do you like monkeys?"
		}
	],
	"position": 2,
	"validation": {
		"sum_text": "",
		"min": "0",
		"text": "Please enter a whole number between {0} and {1}.",
		"sum": null,
		"max": "100",
		"type": "integer"
	},
	"id": "157429231",
	"forced_ranking": false
}
