{
	"sorting": null,
	"family": "single_choice",
	"subtype": "menu",
	"required": null,
	"answers": {
		"other": {
			"num_lines": 1,
			"text": "Other (please specify)",
			"id": "1140048298",
			"visible": true,
			"apply_all_rows": false,
			"is_answer_choice": true,
			"position": 0,
			"num_chars": 50,
			"error_text": "Please enter a comment."
		},
		"choices": [{
				"visible": true,
				"text": "Europe",
				"position": 1,
				"id": "1140048295"
			}, {
				"visible": true,
				"text": "Asia",
				"position": 2,
				"id": "1140048296"
			}, {
				"visible": true,
				"text": "North America",
				"position": 3,
				"id": "1140048297"
			}
		]
	},
	"visible": true,
	"href": "https:\/\/api.surveymonkey.net\/v3\/surveys\/121392425\/pages\/47361247\/questions\/157428180",
	"headings": [{
			"heading": "On which continent were you born?"
		}
	],
	"position": 2,
	"validation": null,
	"id": "157428180",
	"forced_ranking": false
}
