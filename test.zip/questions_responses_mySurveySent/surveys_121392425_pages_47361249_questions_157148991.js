{
	"sorting": null,
	"family": "matrix",
	"subtype": "rating",
	"required": null,
	"answers": {
		"rows": [{
				"visible": true,
				"text": "mother",
				"position": 1,
				"id": "1138208092"
			}, {
				"visible": true,
				"text": "father",
				"position": 2,
				"id": "1138208093"
			}
		],
		"other": {
			"num_lines": 1,
			"text": "comments",
			"id": "1138208105",
			"visible": true,
			"apply_all_rows": true,
			"is_answer_choice": false,
			"position": 0,
			"num_chars": 50,
			"error_text": ""
		},
		"choices": [{
				"description": "",
				"weight": 1,
				"id": "1138208094",
				"visible": true,
				"is_na": false,
				"text": "Chocolate",
				"position": 1
			}, {
				"description": "",
				"weight": 2,
				"id": "1138208095",
				"visible": true,
				"is_na": false,
				"text": "Vanilla",
				"position": 2
			}, {
				"description": "",
				"weight": 3,
				"id": "1138208096",
				"visible": true,
				"is_na": false,
				"text": "Strawberry",
				"position": 3
			}
		]
	},
	"visible": true,
	"href": "https:\/\/api.surveymonkey.net\/v3\/surveys\/121392425\/pages\/47361249\/questions\/157148991",
	"headings": [{
			"heading": "What is each of your family members' favorite ice cream?"
		}
	],
	"position": 1,
	"validation": {
		"sum_text": "",
		"min": "0",
		"text": "The comment you entered is in an invalid format.",
		"sum": null,
		"max": "5000",
		"type": "text_length"
	},
	"id": "157148991",
	"forced_ranking": true
}
